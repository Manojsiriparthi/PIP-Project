#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/terraform"

terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
terraform apply tfplan

CLUSTER_NAME="$(terraform output -raw eks_cluster_name)"
ALB_SG_ID="$(terraform output -raw alb_security_group_id)"

aws eks update-kubeconfig --region ap-south-1 --name "$CLUSTER_NAME"

cd ../kubernetes
kubectl apply -f namespaces.yaml
sed "s/REPLACE_WITH_ALB_SG_ID/${ALB_SG_ID}/" application-deployment.yaml | kubectl apply -f -
kubectl apply -f db-deployment.yaml

kubectl get nodes -o wide
kubectl get pods -A
