output "vpc_id" { value = module.vpc.vpc_id }
output "public_subnet_ids" { value = module.vpc.public_subnet_ids }
output "private_subnet_ids" { value = module.vpc.private_subnet_ids }
output "database_subnet_ids" { value = module.vpc.database_subnet_ids }
output "eks_cluster_name" { value = module.eks.cluster_name }
output "eks_cluster_arn" { value = module.eks.cluster_arn }
output "eks_cluster_endpoint" { value = module.eks.cluster_endpoint }
output "eks_cluster_security_group_id" { value = module.eks.cluster_security_group_id }
output "eks_node_security_group_id" { value = module.eks.node_security_group_id }
output "eks_cluster_iam_role_arn" { value = module.eks.cluster_iam_role_arn }
output "eks_node_iam_role_arn" { value = module.eks.node_iam_role_arn }
output "eks_node_group_names" { value = module.eks.node_group_names }
output "eks_addons" { value = module.eks.addons }

output "alb_security_group_id" {
  value       = module.vpc.alb_security_group_id
  description = "Public ALB security group."
}

output "private_app_security_group_id" {
  value       = module.vpc.private_app_security_group_id
  description = "Private application security group."
}

output "database_security_group_id" {
  value       = module.vpc.database_security_group_id
  description = "Database security group."
}
