variable "cluster_name" { type = string }
variable "cluster_version" { type = string }
variable "vpc_id" { type = string }
variable "private_subnet_ids" { type = list(string) }
variable "database_subnet_ids" { type = list(string) }
variable "alb_security_group_id" { type = string }
variable "private_app_security_group_id" { type = string }
variable "database_security_group_id" { type = string }
variable "node_instance_types" { type = list(string) }
variable "desired_nodes" { type = number }
variable "project_name" { type = string }
variable "environment" { type = string }

module "eks" {
  source = "terraform-aws-modules/eks/aws"
  version = "~> 21.0"
  name = var.cluster_name
  kubernetes_version = var.cluster_version
  endpoint_public_access = true
  endpoint_private_access = true
  vpc_id = var.vpc_id
  subnet_ids = var.private_subnet_ids
  enable_cluster_creator_admin_permissions = true

  addons = {
    vpc-cni = { most_recent = true }
    coredns = { most_recent = true }
    kube-proxy = { most_recent = true }
    eks-pod-identity-agent = { most_recent = true }
    amazon-cloudwatch-observability = { most_recent = true }
  }

  eks_managed_node_groups = {
    app = {
      name = "${var.project_name}-${var.environment}-app"
      instance_types = var.node_instance_types
      min_size = 3
      max_size = 6
      desired_size = var.desired_nodes
      subnet_ids = var.private_subnet_ids
      vpc_security_group_ids = [var.private_app_security_group_id]
      labels = { workload = "application", tier = "private" }
      iam_role_additional_policies = {
        AmazonSSMManagedInstanceCore = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
      }
    }
    db = {
      name = "${var.project_name}-${var.environment}-db"
      instance_types = var.node_instance_types
      min_size = 0
      max_size = 3
      desired_size = 0
      subnet_ids = var.database_subnet_ids
      vpc_security_group_ids = [var.database_security_group_id]
      labels = { workload = "database", tier = "database" }
      taints = { dedicated = { key="dedicated", value="database", effect="NO_SCHEDULE" } }
      iam_role_additional_policies = {
        AmazonSSMManagedInstanceCore = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
      }
    }
  }
  tags = { Project = var.project_name, Environment = var.environment }
}
