output "cluster_name" { value = module.eks.cluster_name }
output "cluster_arn" { value = module.eks.cluster_arn }
output "cluster_endpoint" { value = module.eks.cluster_endpoint }
output "cluster_certificate_authority_data" { value = module.eks.cluster_certificate_authority_data sensitive = true }
output "cluster_security_group_id" { value = module.eks.cluster_security_group_id }
output "node_security_group_id" { value = module.eks.node_security_group_id }
output "cluster_iam_role_arn" { value = module.eks.cluster_iam_role_arn }
output "node_iam_role_arn" { value = module.eks.eks_managed_node_groups["app"].iam_role_arn }
output "node_group_names" { value = keys(module.eks.eks_managed_node_groups) }
output "addons" { value = keys(module.eks.cluster_addons) }
