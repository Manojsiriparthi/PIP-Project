output "vpc_id" { value = module.vpc.vpc_id }
output "public_subnet_ids" { value = module.vpc.public_subnets }
output "private_subnet_ids" { value = module.vpc.private_subnets }
output "database_subnet_ids" { value = module.vpc.database_subnets }
output "public_route_table_ids" { value = module.vpc.public_route_table_ids }
output "private_route_table_ids" { value = module.vpc.private_route_table_ids }
output "database_route_table_ids" { value = module.vpc.database_route_table_ids }
output "nat_gateway_ids" { value = module.vpc.natgw_ids }

output "alb_security_group_id" {
  value = aws_security_group.alb.id
}

output "private_app_security_group_id" {
  value = aws_security_group.private_app.id
}

output "database_security_group_id" {
  value = aws_security_group.db.id
}
