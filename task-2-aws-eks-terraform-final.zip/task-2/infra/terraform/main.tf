data "aws_availability_zones" "available" { state = "available" }

locals {
  azs = var.availability_zones != null ? var.availability_zones : slice(data.aws_availability_zones.available.names, 0, 3)
  public_subnets   = ["10.0.0.0/24", "10.0.1.0/24", "10.0.2.0/24"]
  private_subnets  = ["10.0.10.0/24", "10.0.11.0/24", "10.0.12.0/24"]
  database_subnets = ["10.0.20.0/24", "10.0.21.0/24", "10.0.22.0/24"]
}

module "vpc" {
  source = "./modules/vpc"
  name = "${var.project_name}-${var.environment}"
  vpc_cidr = var.vpc_cidr
  azs = local.azs
  public_subnets = local.public_subnets
  private_subnets = local.private_subnets
  database_subnets = local.database_subnets
  single_nat_gateway = var.enable_single_nat_gateway
  enable_flow_log = true
  cluster_name = "${var.project_name}-${var.environment}-eks"
}

module "eks" {
  source = "./modules/eks"
  cluster_name = "${var.project_name}-${var.environment}-eks"
  cluster_version = var.cluster_version
  vpc_id = module.vpc.vpc_id
  private_subnet_ids = module.vpc.private_subnet_ids
  database_subnet_ids = module.vpc.database_subnet_ids
  node_instance_types = var.node_instance_types
  desired_nodes = var.desired_nodes
  project_name = var.project_name
  environment = var.environment
}
