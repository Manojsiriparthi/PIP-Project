# Workload examples
Apply after EKS:
`kubectl apply -f namespaces.yaml`
`kubectl apply -f application-deployment.yaml`
`kubectl apply -f db-deployment.yaml`

Frontend uses private application nodes and a LoadBalancer service. DB uses a dedicated DB node group, required nodeAffinity, a DB taint/toleration, and ClusterIP. Replace the example DB password with a secret before production.


The Terraform VPC module creates separate ALB, private-app and DB SGs. `deploy.sh` injects the ALB SG ID into the frontend service manifest.
