# Task-2 AWS VPC + EKS Terraform

3-AZ VPC with non-overlapping public/private/DB subnets, route tables, NAT, dedicated NACL tiers, security groups, EKS managed node groups, IAM, and CloudWatch/Fluent Bit observability.

## Layout
- `infra/terraform/` root Terraform
- `infra/terraform/modules/vpc/` reusable VPC module
- `infra/terraform/modules/eks/` reusable EKS module
- `infra/kubernetes/` example workloads and DB node affinity

## Network
VPC `10.0.0.0/16`
- Public: `10.0.0.0/24`, `10.0.1.0/24`, `10.0.2.0/24`
- Private: `10.0.10.0/24`, `10.0.11.0/24`, `10.0.12.0/24`
- DB: `10.0.20.0/24`, `10.0.21.0/24`, `10.0.22.0/24`

App nodes run in private subnets. A separate DB node group uses DB subnets, `workload=database` / `tier=database`, and a DB taint. DB pods use required node affinity and a ClusterIP service.

## Deploy
```bash
cd infra/terraform
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
terraform apply tfplan

aws eks update-kubeconfig --region ap-south-1 --name "$(terraform output -raw eks_cluster_name)"
cd ../kubernetes
kubectl apply -f namespaces.yaml
kubectl apply -f application-deployment.yaml
kubectl apply -f db-deployment.yaml
```

EKS add-ons: `vpc-cni`, `coredns`, `kube-proxy`, `eks-pod-identity-agent`, `amazon-cloudwatch-observability` (CloudWatch + Fluent Bit).

For production DBs, prefer RDS/Aurora unless there is a reason to run DB workloads in EKS.


## Security Group design

The project now creates dedicated security groups:

- `*-alb-sg`: TCP 80/443 from the internet.
- `*-private-app-sg`: application traffic from the ALB and internal app-to-app traffic.
- `*-db-sg`: TCP 5432 only from `private-app-sg`.
- EKS module's cluster/node security groups remain in place for Kubernetes control-plane/node communication.

The app managed node group receives `private-app-sg`; the DB managed node group receives `db-sg`.
The frontend LoadBalancer example is configured by `deploy.sh` to use `alb-sg`.

### Security boundary

```text
Internet
   |
   v
ALB SG : 80/443
   |
   v
Private App SG : application port
   |
   v
DB SG : 5432 only
```

DB has no direct internet ingress. DB subnets also have no NAT/default-internet route.

### Important EKS note

A security group attached to a managed node group protects the EC2 worker nodes. It is not automatically a per-pod security group. For strict pod-level SG isolation, enable AWS VPC CNI security groups for pods and configure `SecurityGroupPolicy` for the DB pods. This task keeps the simpler node-level DB boundary plus Kubernetes node affinity/taints.

Do not commit real credentials; the example PostgreSQL password must be replaced with a Kubernetes Secret/Secrets Manager integration.
