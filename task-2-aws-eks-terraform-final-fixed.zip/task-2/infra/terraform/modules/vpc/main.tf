variable "name" { type = string }
variable "vpc_cidr" { type = string }
variable "azs" { type = list(string) }
variable "public_subnets" { type = list(string) }
variable "private_subnets" { type = list(string) }
variable "database_subnets" { type = list(string) }
variable "single_nat_gateway" {
  type    = bool
  default = false
}
variable "enable_flow_log" { type = bool default = true }
variable "cluster_name" { type = string }

module "vpc" {
  source = "terraform-aws-modules/vpc/aws"
  version = "~> 6.0"
  name = var.name
  cidr = var.vpc_cidr
  azs = var.azs
  public_subnets = var.public_subnets
  private_subnets = var.private_subnets
  database_subnets = var.database_subnets
  enable_dns_hostnames = true
  enable_dns_support = true
  enable_nat_gateway = true
  single_nat_gateway = var.single_nat_gateway
  create_database_subnet_route_table = true
  create_database_nat_gateway_route = false

  public_dedicated_network_acl = true
  private_dedicated_network_acl = true
  database_dedicated_network_acl = true

  public_inbound_acl_rules = [{rule_number=100,rule_action="allow",from_port=0,to_port=0,protocol="-1",cidr_block="0.0.0.0/0"}]
  public_outbound_acl_rules = [{rule_number=100,rule_action="allow",from_port=0,to_port=0,protocol="-1",cidr_block="0.0.0.0/0"}]
  private_inbound_acl_rules = [{rule_number=100,rule_action="allow",from_port=0,to_port=0,protocol="-1",cidr_block=var.vpc_cidr}]
  private_outbound_acl_rules = [{rule_number=100,rule_action="allow",from_port=0,to_port=0,protocol="-1",cidr_block="0.0.0.0/0"}]
  database_inbound_acl_rules = [{rule_number=100,rule_action="allow",from_port=0,to_port=0,protocol="-1",cidr_block=var.vpc_cidr}]
  database_outbound_acl_rules = [{rule_number=100,rule_action="allow",from_port=0,to_port=0,protocol="-1",cidr_block=var.vpc_cidr}]

  enable_flow_log = var.enable_flow_log
  flow_log_destination_type = "cloud-watch-logs"
  flow_log_traffic_type = "ALL"
  create_flow_log_cloudwatch_iam_role = true
  create_flow_log_cloudwatch_log_group = true

  public_subnet_tags = {"kubernetes.io/role/elb"="1","kubernetes.io/cluster/${var.cluster_name}"="shared","Tier"="public"}
  private_subnet_tags = {"kubernetes.io/role/internal-elb"="1","kubernetes.io/cluster/${var.cluster_name}"="shared","Tier"="private"}
  database_subnet_tags = {"Tier"="database"}
  tags = {"kubernetes.io/cluster/${var.cluster_name}"="shared"}
}


# Dedicated security groups for the three workload tiers.
# These are intentionally separate from the EKS cluster/node security groups.
resource "aws_security_group" "alb" {
  name        = "${var.name}-alb-sg"
  description = "Public ALB security group"
  vpc_id      = module.vpc.vpc_id

  ingress {
    description = "HTTP"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "HTTPS"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    description = "Outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.name}-alb-sg", Tier = "public" }
}

resource "aws_security_group" "private_app" {
  name        = "${var.name}-private-app-sg"
  description = "Private application/EKS workload security group"
  vpc_id      = module.vpc.vpc_id

  # Allow application traffic only from the public ALB tier.
  ingress {
    description     = "Application traffic from ALB"
    from_port       = 80
    to_port         = 80
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }

  # Allow internal application-to-application traffic.
  ingress {
    description = "Internal application traffic"
    from_port   = 0
    to_port     = 65535
    protocol    = "tcp"
    self        = true
  }

  egress {
    description = "Outbound to private/NAT destinations"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.name}-private-app-sg", Tier = "private" }
}

resource "aws_security_group" "db" {
  name        = "${var.name}-db-sg"
  description = "Database tier security group"
  vpc_id      = module.vpc.vpc_id

  # PostgreSQL is only reachable from the private application tier.
  ingress {
    description     = "PostgreSQL from private application tier"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.private_app.id]
  }

  egress {
    description = "Database outbound inside VPC"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = [var.vpc_cidr]
  }

  tags = { Name = "${var.name}-db-sg", Tier = "database" }
}
