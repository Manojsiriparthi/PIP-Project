variable "aws_region" {
  type    = string
  default = "ap-south-1"
}
variable "project_name" {
  type    = string
  default = "task-2"
}
variable "environment" {
  type    = string
  default = "dev"
}
variable "vpc_cidr" {
  type    = string
  default = "10.0.0.0/16"
}
variable "availability_zones" {
  type    = list(string)
  default = null
}
variable "cluster_version" {
  type    = string
  default = "1.33"
}
variable "node_instance_types" {
  type    = list(string)
  default = ["t3.medium"]
}
variable "desired_nodes" {
  type    = number
  default = 3
}
variable "enable_single_nat_gateway" {
  type    = bool
  default = false
}
